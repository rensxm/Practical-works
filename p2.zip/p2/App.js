import React, { useState } from "react";
import { View, Text, Button, Image, StyleSheet, ScrollView } from "react-native";

// ---------- Данные ----------
const places = [
  { id: 1, name: "Эйфелева башня", category: "Достопримечательности", description: "Главный символ Парижа", imageUrl: "https://picsum.photos/400/200?random=1", rating: 4.8 },
  { id: 2, name: "Лувр", category: "Достопримечательности", description: "Музей мирового уровня", imageUrl: "https://picsum.photos/400/200?random=2", rating: 4.9 },
  { id: 3, name: "Парк Люксембург", category: "Парки", description: "Популярное место отдыха", imageUrl: "https://picsum.photos/400/200?random=3", rating: 4.5 },
  { id: 4, name: "Le Meurice", category: "Рестораны", description: "Французская кухня", imageUrl: "https://picsum.photos/400/200?random=4", rating: 4.7 }
];

const categories = ["Достопримечательности", "Парки", "Рестораны"];

// ---------- Главный компонент ----------
export default function App() {
  const [screen, setScreen] = useState("categories");
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [selectedPlace, setSelectedPlace] = useState(null);

  if (screen === "categories") {
    return (
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.header}>Категории</Text>
        {categories.map((cat) => (
          <View key={cat} style={styles.card}>
            <Button
              title={cat}
              onPress={() => {
                setSelectedCategory(cat);
                setScreen("places");
              }}
            />
          </View>
        ))}
      </ScrollView>
    );
  }

  if (screen === "places") {
    const filtered = places.filter((p) => p.category === selectedCategory);
    return (
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.header}>{selectedCategory}</Text>
        {filtered.map((place) => (
          <View key={place.id} style={styles.card}>
            <Image source={{ uri: place.imageUrl }} style={styles.image} />
            <Text style={styles.title}>{place.name}</Text>
            <Button
              title="Подробнее"
              onPress={() => {
                setSelectedPlace(place);
                setScreen("details");
              }}
            />
          </View>
        ))}
        <Button title="Назад" onPress={() => setScreen("categories")} />
      </ScrollView>
    );
  }

  if (screen === "details" && selectedPlace) {
    return (
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.header}>{selectedPlace.name}</Text>
        <Image source={{ uri: selectedPlace.imageUrl }} style={styles.image} />
        <Text style={styles.description}>{selectedPlace.description}</Text>
        <Text>Рейтинг: {selectedPlace.rating}</Text>
        <Button title="Назад к списку" onPress={() => setScreen("places")} />
      </ScrollView>
    );
  }

  return null;
}

// ---------- Стили ----------
const styles = StyleSheet.create({
  container: { padding: 20, alignItems: "center" },
  header: { fontSize: 22, fontWeight: "bold", marginBottom: 20 },
  card: {
    backgroundColor: "#fff",
    borderRadius: 8,
    padding: 10,
    marginBottom: 15,
    width: "100%",
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3
  },
  image: { width: "100%", height: 200, borderRadius: 8, marginBottom: 10 },
  title: { fontSize: 18, fontWeight: "bold", marginBottom: 5 },
  description: { fontSize: 14, color: "#333", marginBottom: 10 }
});


